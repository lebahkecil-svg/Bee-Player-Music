package com.beeplayer.music.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.beeplayer.music.data.LibraryStore

@Composable
fun ImportScreen(
    vm: LibraryViewModel,
    hasPermission: Boolean,
    requestPermission: () -> Unit,
    onOpenPlayer: () -> Unit
) {
    val ctx = LocalContext.current
    val imported by LibraryStore.imported.collectAsState()

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) vm.importFiles(ctx, uris)
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.importTree(ctx, uri)
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Import pustaka", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "Tambahkan musik dari penyimpanan mana pun (memori internal, kartu SD, folder unduhan). " +
                        "Judul, artis, durasi, dan sampul dibaca dari tag lagu.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pickFolder.launch(null) }, enabled = !vm.importing) {
                    Icon(Icons.Rounded.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Pilih folder")
                }
                OutlinedButton(onClick = { pickFiles.launch(arrayOf("audio/*")) }, enabled = !vm.importing) {
                    Icon(Icons.Rounded.MusicNote, null); Spacer(Modifier.width(6.dp)); Text("Pilih file")
                }
            }
            OutlinedButton(onClick = {
                if (hasPermission) vm.loadLocal(ctx) else requestPermission()
            }) {
                Icon(Icons.Rounded.Refresh, null); Spacer(Modifier.width(6.dp))
                Text(if (hasPermission) "Pindai ulang musik perangkat" else "Izinkan & pindai musik perangkat")
            }
            if (vm.importing) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Membaca… ${vm.importCount} lagu")
                }
            }
            vm.importMsg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Lagu hasil impor: ${imported.size}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                TextButton(enabled = imported.isNotEmpty(), onClick = { LibraryStore.clearImported() }) { Text("Kosongkan") }
            }
        }
        PlayShuffleBar(imported, onOpenPlayer)
        TrackListView(
            imported, "Belum ada lagu yang diimpor.", onOpenPlayer,
            onRemove = { LibraryStore.removeImported(it.id) }
        )
    }
}
