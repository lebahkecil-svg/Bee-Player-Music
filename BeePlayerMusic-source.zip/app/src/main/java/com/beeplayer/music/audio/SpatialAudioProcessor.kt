package com.beeplayer.music.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.beeplayer.music.data.SpatialMode
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Pengolah suara real-time (PCM 16-bit, 1–2 kanal) → keluaran selalu stereo.
 *  MONO   : L+R digabung
 *  STEREO : tanpa perubahan
 *  3D     : pelebaran sisi, crossfeed berjeda + low-pass (efek bayangan kepala), pantulan ruang
 *  4D     : 3D + suara berputar mengelilingi kepala (periode 10 dtk)
 */
class SpatialAudioProcessor : BaseAudioProcessor() {
    @Volatile var mode: SpatialMode = SpatialMode.STEREO

    private val size = 2048
    private val mask = size - 1
    private val bufL = FloatArray(size)
    private val bufR = FloatArray(size)
    private val bufM = FloatArray(size)
    private var pos = 0
    private var lpL = 0f
    private var lpR = 0f
    private var lpA = 0.2f
    private var itd = 18
    private var refl1 = 500
    private var refl2 = 750
    private var sampleRate = 44100
    private var inChannels = 2
    private var phase = 0.0
    private var analyzer = SpectrumAnalyzer(44100)

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount !in 1..2) {
            return AudioProcessor.AudioFormat.NOT_SET // tidak aktif, audio lewat apa adanya
        }
        sampleRate = inputAudioFormat.sampleRate
        inChannels = inputAudioFormat.channelCount
        analyzer = SpectrumAnalyzer(sampleRate)
        lpA = (1.0 - exp(-2.0 * PI * 1500.0 / sampleRate)).toFloat()
        itd = (sampleRate * 0.0004).toInt().coerceIn(2, 200)
        refl1 = (sampleRate * 0.011).toInt().coerceIn(2, size - 1)
        refl2 = (sampleRate * 0.017).toInt().coerceIn(2, size - 1)
        return AudioProcessor.AudioFormat(sampleRate, 2, C.ENCODING_PCM_16BIT)
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val frameBytes = 2 * inChannels
        val frames = remaining / frameBytes
        val out = replaceOutputBuffer(frames * 4)
        val m = mode
        val lfoStep = 2.0 * PI / (sampleRate * 10.0)

        for (i in 0 until frames) {
            var l = inputBuffer.short / 32768f
            var r = if (inChannels == 2) inputBuffer.short / 32768f else l

            val mid = (l + r) * 0.5f
            var wl = l
            var wr = r

            when (m) {
                SpatialMode.MONO -> { l = mid; r = mid }
                SpatialMode.STEREO -> { }
                SpatialMode.SURROUND_3D, SpatialMode.IMMERSIVE_4D -> {
                    val side = (l - r) * 0.5f * 1.6f
                    wl = mid + side
                    wr = mid - side
                    val dl = bufR[(pos - itd) and mask]
                    val dr = bufL[(pos - itd) and mask]
                    lpL += lpA * (dl - lpL)
                    lpR += lpA * (dr - lpR)
                    l = (wl * 0.85f + 0.4f * lpL + 0.10f * bufM[(pos - refl1) and mask]) * 0.85f
                    r = (wr * 0.85f + 0.4f * lpR + 0.10f * bufM[(pos - refl2) and mask]) * 0.85f
                    if (m == SpatialMode.IMMERSIVE_4D) {
                        val s = sin(phase).toFloat()
                        l *= 0.55f + 0.45f * s
                        r *= 0.55f - 0.45f * s
                        phase += lfoStep
                        if (phase > 2 * PI) phase -= 2 * PI
                    }
                }
            }

            bufL[pos] = wl
            bufR[pos] = wr
            bufM[pos] = mid
            pos = (pos + 1) and mask

            analyzer.push((l + r) * 0.5f)
            out.putShort(toShort(l))
            out.putShort(toShort(r))
        }
        inputBuffer.position(inputBuffer.limit())
        out.flip()
    }

    private fun toShort(v: Float): Short {
        val c = if (v > 1f) 1f else if (v < -1f) -1f else v
        return (c * 32767f).toInt().toShort()
    }

    override fun onFlush() {
        bufL.fill(0f); bufR.fill(0f); bufM.fill(0f)
        pos = 0; lpL = 0f; lpR = 0f
        analyzer.reset()
    }

    override fun onReset() {
        onFlush()
        phase = 0.0
    }
}
