package com.beeplayer.music.audio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.beeplayer.music.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.coroutineContext

/** Mendekode lagu menjadi PCM lalu menulis WAV dengan urutan frame dibalik (putar mundur). */
object ReverseDecoder {

    fun isReversedFile(uri: Uri?): Boolean = uri?.path?.contains("/rev_") == true

    suspend fun reverse(ctx: Context, track: Track): File? = withContext(Dispatchers.IO) {
        if (track.durationMs > 15 * 60_000L) return@withContext null
        val out = File(ctx.cacheDir, "rev_${track.id.hashCode().toUInt()}.wav")
        if (out.exists() && out.length() > 44) return@withContext out
        pruneCache(ctx, keep = 3)

        val raw = File(ctx.cacheDir, "rev_tmp.pcm")
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        var sr = 44100
        var ch = 2
        try {
            ex.setDataSource(ctx, Uri.parse(track.uri), null)
            var idx = -1
            for (i in 0 until ex.trackCount) {
                if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; break }
            }
            if (idx < 0) return@withContext null
            ex.selectTrack(idx)
            val fmt = ex.getTrackFormat(idx)
            sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()

            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            BufferedOutputStream(FileOutputStream(raw), 1 shl 16).use { fos ->
                while (!outDone) {
                    coroutineContext.ensureActive()
                    if (!inDone) {
                        val i = dec.dequeueInputBuffer(10_000)
                        if (i >= 0) {
                            val buf = dec.getInputBuffer(i)!!
                            val n = ex.readSampleData(buf, 0)
                            if (n < 0) {
                                dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inDone = true
                            } else {
                                dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }
                    val o = dec.dequeueOutputBuffer(info, 10_000)
                    when {
                        o >= 0 -> {
                            val b = dec.getOutputBuffer(o)!!
                            if (info.size > 0) {
                                b.position(info.offset)
                                b.limit(info.offset + info.size)
                                val arr = ByteArray(info.size)
                                b.get(arr)
                                fos.write(arr)
                            }
                            dec.releaseOutputBuffer(o, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                        }
                        o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val nf = dec.outputFormat
                            sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            raw.delete()
            return@withContext null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { ex.release() }
        }

        try {
            val frame = ch * 2
            val total = raw.length() / frame * frame
            RandomAccessFile(raw, "r").use { raf ->
                BufferedOutputStream(FileOutputStream(out), 1 shl 16).use { os ->
                    os.write(wavHeader(total, sr, ch))
                    val chunkBytes = 8192 * frame
                    val buf = ByteArray(chunkBytes)
                    val rev = ByteArray(chunkBytes)
                    var end = total
                    while (end > 0) {
                        coroutineContext.ensureActive()
                        val start = maxOf(0L, end - chunkBytes)
                        val len = (end - start).toInt()
                        raf.seek(start)
                        raf.readFully(buf, 0, len)
                        val nf = len / frame
                        for (k in 0 until nf) System.arraycopy(buf, (nf - 1 - k) * frame, rev, k * frame, frame)
                        os.write(rev, 0, len)
                        end = start
                    }
                }
            }
            out
        } catch (e: Exception) {
            out.delete()
            null
        } finally {
            raw.delete()
        }
    }

    private fun wavHeader(dataLen: Long, sr: Int, ch: Int): ByteArray {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()).putInt((36 + dataLen).toInt()).put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(ch.toShort())
        b.putInt(sr).putInt(sr * ch * 2).putShort((ch * 2).toShort()).putShort(16)
        b.put("data".toByteArray()).putInt(dataLen.toInt())
        return b.array()
    }

    private fun pruneCache(ctx: Context, keep: Int) {
        ctx.cacheDir.listFiles { f -> f.name.startsWith("rev_") && f.name.endsWith(".wav") }
            ?.sortedByDescending { it.lastModified() }
            ?.drop(keep)
            ?.forEach { it.delete() }
    }
}
