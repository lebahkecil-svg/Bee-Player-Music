package com.beeplayer.music.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.clickable
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.beeplayer.music.data.Presets
import com.beeplayer.music.data.SettingsStore
import com.beeplayer.music.data.SpatialMode

@Composable
fun SoundScreen() {
    val s by SettingsStore.state.collectAsState()
    var showSave by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Pengaturan Suara", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Semua pengaturan tersimpan otomatis dan dipakai lagi saat aplikasi dibuka.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        SectionTitle("Keluaran suara")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SpatialMode.values().forEach { m ->
                FilterChip(selected = s.spatial == m, onClick = { SettingsStore.update { it.copy(spatial = m) } },
                    label = { Text(m.label) })
            }
        }
        Text(s.spatial.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        SectionTitle("Mode suara")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Presets.builtin.forEach { (name, g) ->
                FilterChip(selected = s.preset == name,
                    onClick = { SettingsStore.update { it.copy(preset = name, bands = g) } },
                    label = { Text(name) })
            }
            s.custom.forEach { (name, g) ->
                FilterChip(selected = s.preset == name,
                    onClick = { SettingsStore.update { it.copy(preset = name, bands = g) } },
                    label = { Text(name) },
                    trailingIcon = {
                        Icon(Icons.Rounded.Close, "Hapus", Modifier.size(16.dp).clickableNoRipple {
                            SettingsStore.update { st ->
                                st.copy(custom = st.custom - name, preset = if (st.preset == name) "Kustom" else st.preset)
                            }
                        })
                    })
            }
        }

        SectionTitle("Preamp   ${fmtDb(s.preampDb)}")
        Slider(value = s.preampDb, onValueChange = { v -> SettingsStore.update { it.copy(preampDb = (Math.round(v * 2) / 2f)) } },
            valueRange = -12f..12f)

        SectionTitle("Equalizer")
        Presets.bands.forEachIndexed { i, hz ->
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(if (hz >= 1000) "${hz / 1000f} kHz".replace(".0", "") else "$hz Hz", Modifier.width(72.dp),
                    style = MaterialTheme.typography.labelLarge)
                Slider(
                    value = s.bands[i], valueRange = -12f..12f, modifier = Modifier.weight(1f),
                    onValueChange = { v ->
                        SettingsStore.update { st ->
                            st.copy(bands = st.bands.toMutableList().also { it[i] = Math.round(v * 2) / 2f }, preset = "Kustom")
                        }
                    })
                Text(fmtDb(s.bands[i]), Modifier.width(64.dp), style = MaterialTheme.typography.labelMedium)
            }
        }

        SectionTitle("Efek tambahan")
        Text("Bass Boost  ${s.bass / 10}%", style = MaterialTheme.typography.labelLarge)
        Slider(value = s.bass.toFloat(), valueRange = 0f..1000f,
            onValueChange = { v -> SettingsStore.update { it.copy(bass = v.toInt()) } })
        Text("Virtualizer (lebar suara)  ${s.virtualizer / 10}%", style = MaterialTheme.typography.labelLarge)
        Slider(value = s.virtualizer.toFloat(), valueRange = 0f..1000f,
            onValueChange = { v -> SettingsStore.update { it.copy(virtualizer = v.toInt()) } })

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { showSave = true }) { Text("Simpan sebagai mode") }
            OutlinedButton(onClick = {
                SettingsStore.update { it.copy(preampDb = 0f, bands = List(5) { 0f }, preset = "Flat", bass = 0, virtualizer = 0) }
            }) { Text("Reset") }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showSave) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSave = false },
            title = { Text("Simpan pengaturan") },
            text = {
                OutlinedTextField(name, { name = it.filter { c -> c != '=' && c != ';' && c != ',' }.take(20) },
                    label = { Text("Nama mode (mis. Favoritku)") }, singleLine = true)
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    val n = name.trim()
                    SettingsStore.update { it.copy(custom = it.custom + (n to it.bands), preset = n) }
                    showSave = false
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { showSave = false }) { Text("Batal") } }
        )
    }
}

private fun fmtDb(v: Float) = (if (v > 0) "+" else "") + "%.1f dB".format(v)

@Composable
private fun SectionTitle(t: String) =
    Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = composed {
    clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
        indication = null, onClick = onClick)
}
