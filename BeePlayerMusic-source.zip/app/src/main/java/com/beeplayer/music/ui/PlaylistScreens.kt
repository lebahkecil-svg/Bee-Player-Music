package com.beeplayer.music.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.beeplayer.music.data.LibraryStore
import com.beeplayer.music.data.Playlist
import com.beeplayer.music.data.Track
import com.beeplayer.music.service.PlayerController

// ---------------- dialog ----------------

@Composable
fun NameDialog(title: String, initial: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(name, { name = it.take(40) }, singleLine = true, label = { Text("Nama") })
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name.trim()) }) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun AddToPlaylistDialog(track: Track, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val lists by LibraryStore.playlists.collectAsState()
    var creating by remember { mutableStateOf(false) }

    if (creating) {
        NameDialog("Daftar putar baru", "", "Buat", onDismiss = { creating = false }) { n ->
            val id = LibraryStore.createPlaylist(n)
            LibraryStore.addToPlaylist(id, track)
            Toast.makeText(ctx, "Ditambahkan ke \"$n\"", Toast.LENGTH_SHORT).show()
            creating = false
            onDismiss()
        }
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah ke daftar putar") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TextButton(onClick = { creating = true }) {
                    Icon(Icons.Rounded.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Daftar putar baru")
                }
                lists.forEach { p ->
                    Text(
                        "${p.name}  (${p.tracks.size})",
                        Modifier.fillMaxWidth().clickable {
                            val ok = LibraryStore.addToPlaylist(p.id, track)
                            Toast.makeText(
                                ctx, if (ok) "Ditambahkan ke \"${p.name}\"" else "Sudah ada di \"${p.name}\"",
                                Toast.LENGTH_SHORT
                            ).show()
                            onDismiss()
                        }.padding(vertical = 12.dp, horizontal = 8.dp)
                    )
                }
                if (lists.isEmpty()) Text("Belum ada daftar putar.", Modifier.padding(8.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup") } }
    )
}

// ---------------- daftar lagu bersama ----------------

@Composable
fun TrackListView(
    tracks: List<Track>,
    emptyText: String,
    onOpenPlayer: () -> Unit,
    modifier: Modifier = Modifier,
    onRemove: ((Track) -> Unit)? = null
) {
    val ui by PlayerController.ui.collectAsState()
    if (tracks.isEmpty()) {
        Box(modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(emptyText, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    LazyColumn(modifier.fillMaxSize()) {
        itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
            TrackRow(
                t, ui.current?.id == t.id,
                onClick = { PlayerController.playQueue(tracks, i); onOpenPlayer() },
                onRemove = onRemove?.let { r -> { r(t) } }
            )
        }
    }
}

@Composable
fun PlayShuffleBar(tracks: List<Track>, onOpenPlayer: () -> Unit, extra: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            enabled = tracks.isNotEmpty(),
            onClick = { PlayerController.playQueue(tracks, 0); onOpenPlayer() }
        ) {
            Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Putar")
        }
        OutlinedButton(
            enabled = tracks.isNotEmpty(),
            onClick = { PlayerController.playQueue(tracks.shuffled(), 0); onOpenPlayer() }
        ) {
            Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(4.dp)); Text("Acak")
        }
        Spacer(Modifier.weight(1f))
        extra()
    }
}

// ---------------- layar ----------------

@Composable
fun PlaylistsScreen(openId: String?, onOpen: (String?) -> Unit, onOpenPlayer: () -> Unit) {
    val lists by LibraryStore.playlists.collectAsState()
    var showCreate by remember { mutableStateOf(false) }

    val open = lists.firstOrNull { it.id == openId }
    if (open != null) {
        PlaylistDetail(open, onBack = { onOpen(null) }, onOpenPlayer = onOpenPlayer)
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${lists.size} daftar putar", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { showCreate = true }) {
                Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("Buat baru")
            }
        }
        if (lists.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Belum ada daftar putar.\nKetuk \"Buat baru\", atau pilih menu ⋮ pada lagu lalu \"Tambah ke daftar putar\".",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(lists, key = { _, p -> p.id }) { _, p -> PlaylistRow(p, onClick = { onOpen(p.id) }) }
            }
        }
    }
    if (showCreate) {
        NameDialog("Daftar putar baru", "", "Buat", onDismiss = { showCreate = false }) { n ->
            val id = LibraryStore.createPlaylist(n)
            showCreate = false
            onOpen(id)
        }
    }
}

@Composable
private fun PlaylistRow(p: Playlist, onClick: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.QueueMusic, null, tint = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text("${p.tracks.size} lagu", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "Menu") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Ganti nama") }, onClick = { menu = false; rename = true })
                DropdownMenuItem(text = { Text("Hapus daftar putar") }, onClick = { menu = false; delete = true })
            }
        }
    }
    if (rename) NameDialog("Ganti nama", p.name, "Simpan", onDismiss = { rename = false }) { n ->
        LibraryStore.renamePlaylist(p.id, n); rename = false
    }
    if (delete) AlertDialog(
        onDismissRequest = { delete = false },
        title = { Text("Hapus \"${p.name}\"?") },
        text = { Text("Lagu di dalamnya tidak ikut terhapus dari perangkat.") },
        confirmButton = { TextButton(onClick = { LibraryStore.deletePlaylist(p.id); delete = false }) { Text("Hapus") } },
        dismissButton = { TextButton(onClick = { delete = false }) { Text("Batal") } }
    )
}

@Composable
private fun PlaylistDetail(p: Playlist, onBack: () -> Unit, onOpenPlayer: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Kembali") }
            Column(Modifier.weight(1f)) {
                Text(p.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("${p.tracks.size} lagu", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        PlayShuffleBar(p.tracks, onOpenPlayer)
        TrackListView(
            p.tracks, "Daftar putar ini masih kosong.\nTambahkan lagu lewat menu ⋮ pada lagu.", onOpenPlayer,
            onRemove = { LibraryStore.removeFromPlaylist(p.id, it.id) }
        )
    }
}

@Composable
fun FavoritesScreen(onOpenPlayer: () -> Unit) {
    val favs by LibraryStore.favorites.collectAsState()
    Column(Modifier.fillMaxSize()) {
        PlayShuffleBar(favs, onOpenPlayer) {
            Text("${favs.size} lagu", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        TrackListView(
            favs, "Belum ada favorit.\nKetuk ikon ♥ di layar Sedang Memutar, atau menu ⋮ pada lagu.", onOpenPlayer,
            onRemove = { LibraryStore.toggleFavorite(it) }
        )
    }
}

@Composable
fun RecentsScreen(onOpenPlayer: () -> Unit) {
    val rec by LibraryStore.recents.collectAsState()
    Column(Modifier.fillMaxSize()) {
        PlayShuffleBar(rec, onOpenPlayer) {
            TextButton(enabled = rec.isNotEmpty(), onClick = { LibraryStore.clearRecents() }) { Text("Hapus riwayat") }
        }
        TrackListView(rec, "Belum ada lagu yang diputar.", onOpenPlayer)
    }
}
