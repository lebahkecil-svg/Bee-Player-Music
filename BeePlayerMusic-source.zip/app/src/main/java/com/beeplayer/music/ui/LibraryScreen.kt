package com.beeplayer.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.beeplayer.music.R
import com.beeplayer.music.data.LocalLibrary
import com.beeplayer.music.data.OnlineSource
import com.beeplayer.music.data.Track
import com.beeplayer.music.service.PlayerController
import kotlinx.coroutines.launch

class LibraryViewModel : ViewModel() {
    var local by mutableStateOf<List<Track>>(emptyList())
    var loadingLocal by mutableStateOf(false)
    var online by mutableStateOf<List<Track>>(emptyList())
    var searching by mutableStateOf(false)
    var onlineMsg by mutableStateOf<String?>(null)

    fun loadLocal(ctx: android.content.Context) {
        viewModelScope.launch {
            loadingLocal = true
            local = LocalLibrary.load(ctx.applicationContext)
            loadingLocal = false
        }
    }

    fun searchOnline(q: String) {
        if (q.isBlank()) return
        viewModelScope.launch {
            searching = true
            onlineMsg = null
            online = OnlineSource.search(q)
            if (online.isEmpty()) onlineMsg = "Tidak ada hasil, atau tidak ada koneksi internet."
            searching = false
        }
    }
}

@Composable
fun LibraryScreen(
    vm: LibraryViewModel,
    hasPermission: Boolean,
    requestPermission: () -> Unit,
    onOpenPlayer: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    val ui by PlayerController.ui.collectAsState()
    val focus = LocalFocusManager.current
    val ctx = LocalContext.current

    LaunchedEffect(hasPermission) { if (hasPermission) vm.loadLocal(ctx) }

    val shownLocal = remember(vm.local, query) {
        if (query.isBlank()) vm.local else vm.local.filter {
            it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painterResource(R.drawable.bee_logo), null,
                Modifier.size(44.dp).clip(RoundedCornerShape(10.dp))
            )
            Spacer(Modifier.width(10.dp))
            Text("Bee Player Music", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(16.dp, 10.dp),
            placeholder = { Text(if (tab == 0) "Cari lagu di perangkat…" else "Cari lagu online… lalu tekan Cari") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                if (tab == 1) vm.searchOnline(query)
                focus.clearFocus()
            })
        )
        TabRow(selectedTabIndex = tab, containerColor = androidx.compose.ui.graphics.Color.Transparent) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Internal") }, icon = { Icon(Icons.Rounded.PhoneAndroid, null) })
            Tab(tab == 1, { tab = 1 }, text = { Text("Online") }, icon = { Icon(Icons.Rounded.Cloud, null) })
        }

        if (tab == 0) {
            when {
                !hasPermission -> Center {
                    Text("Izinkan akses ke musik di perangkat untuk melihat pustaka.", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = requestPermission) { Text("Izinkan akses musik") }
                }
                vm.loadingLocal -> Center { CircularProgressIndicator() }
                shownLocal.isEmpty() -> Center { Text("Tidak ada lagu ditemukan.") }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(shownLocal, key = { _, t -> t.id }) { i, t ->
                        TrackRow(t, ui.current?.id == t.id) {
                            PlayerController.playQueue(shownLocal, i); onOpenPlayer()
                        }
                    }
                }
            }
        } else {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { vm.searchOnline(query); focus.clearFocus() }, enabled = query.isNotBlank() && !vm.searching) {
                    Text("Cari")
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    "Sumber: Audius (lagu penuh), cadangan iTunes (cuplikan 30 dtk)",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            when {
                vm.searching -> Center { CircularProgressIndicator() }
                vm.online.isEmpty() -> Center { Text(vm.onlineMsg ?: "Ketik judul/artis, lalu tekan Cari.", textAlign = TextAlign.Center) }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(vm.online, key = { _, t -> t.id }) { i, t ->
                        TrackRow(t, ui.current?.id == t.id) {
                            PlayerController.playQueue(vm.online, i); onOpenPlayer()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Center(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}
