package com.beeplayer.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class SpatialMode(val label: String, val desc: String) {
    MONO("Mono", "Kedua kanal digabung menjadi satu suara tunggal."),
    STEREO("Stereo", "Suara asli kiri & kanan, tanpa pengolahan ruang."),
    SURROUND_3D("Real 3D", "Pemisahan ruang binaural (lebar, jeda antar telinga, pantulan ruang). Terbaik dengan headphone."),
    IMMERSIVE_4D("Real 4D", "3D ditambah gerakan suara yang berputar mengelilingi kepala (efek 8D). Terbaik dengan headphone.")
}

enum class SpectrumStyle(val label: String) {
    BARS("Batang Klasik"),
    MIRROR("Cermin"),
    CIRCLE("Lingkaran"),
    WAVE("Gelombang"),
    DOTS("Titik Matriks"),
    BLOCKS("LED Segmen"),
    PULSE("Denyut")
}

object Presets {
    /** Frekuensi acuan 5 pita (Hz). */
    val bands = listOf(60, 230, 910, 3600, 14000)

    val builtin: LinkedHashMap<String, List<Float>> = linkedMapOf(
        "Flat" to listOf(0f, 0f, 0f, 0f, 0f),
        "Rock" to listOf(5f, 3f, -2f, 3f, 5f),
        "Jazz" to listOf(3f, 2f, -2f, 2f, 4f),
        "Alternatif" to listOf(4f, 1f, -1f, 3f, 3f),
        "Pop" to listOf(-1f, 2f, 4f, 2f, -1f),
        "Klasik" to listOf(3f, 2f, 0f, 2f, 3f),
        "Hip-Hop" to listOf(6f, 4f, 0f, 1f, 3f),
        "EDM" to listOf(6f, 3f, 0f, 2f, 5f),
        "Akustik" to listOf(3f, 3f, 2f, 2f, 3f),
        "Vokal" to listOf(-2f, 0f, 4f, 3f, 0f),
        "Bass Boost" to listOf(8f, 5f, 0f, 0f, 0f),
        "Treble Boost" to listOf(0f, 0f, 0f, 4f, 8f)
    )
}

data class AudioSettings(
    val preampDb: Float = 0f,
    val bands: List<Float> = List(5) { 0f },
    val preset: String = "Flat",
    val bass: Int = 0,
    val virtualizer: Int = 0,
    val spatial: SpatialMode = SpatialMode.STEREO,
    val skin: String = "Madu",
    val custom: Map<String, List<Float>> = emptyMap(),
    val spectrum: SpectrumStyle = SpectrumStyle.BARS,
    val spectrumGain: Float = 1f,
    val hero: String = "cover"
)

/** Semua pengaturan disimpan otomatis ke SharedPreferences. */
object SettingsStore {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(AudioSettings())
    val state: StateFlow<AudioSettings> = _state.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("bee_settings", Context.MODE_PRIVATE)
        _state.value = load()
    }

    fun update(block: (AudioSettings) -> AudioSettings) {
        _state.update(block)
        save(_state.value)
    }

    private fun parseBands(s: String?): List<Float>? {
        val l = s?.split(",")?.mapNotNull { it.toFloatOrNull() }
        return if (l != null && l.size == 5) l else null
    }

    private fun load(): AudioSettings = runCatching {
        val custom = LinkedHashMap<String, List<Float>>()
        prefs.getString("custom", "")?.split(";")?.forEach { e ->
            val p = e.split("=")
            if (p.size == 2) parseBands(p[1])?.let { custom[p[0]] = it }
        }
        AudioSettings(
            preampDb = prefs.getFloat("preamp", 0f),
            bands = parseBands(prefs.getString("bands", null)) ?: List(5) { 0f },
            preset = prefs.getString("preset", "Flat") ?: "Flat",
            bass = prefs.getInt("bass", 0),
            virtualizer = prefs.getInt("virt", 0),
            spatial = runCatching { SpatialMode.valueOf(prefs.getString("spatial", "STEREO")!!) }
                .getOrDefault(SpatialMode.STEREO),
            skin = prefs.getString("skin", "Madu") ?: "Madu",
            custom = custom,
            spectrum = runCatching { SpectrumStyle.valueOf(prefs.getString("spectrum", "BARS")!!) }
                .getOrDefault(SpectrumStyle.BARS),
            spectrumGain = prefs.getFloat("sgain", 1f),
            hero = prefs.getString("hero", "cover") ?: "cover"
        )
    }.getOrDefault(AudioSettings())

    private fun save(s: AudioSettings) {
        prefs.edit()
            .putFloat("preamp", s.preampDb)
            .putString("bands", s.bands.joinToString(","))
            .putString("preset", s.preset)
            .putInt("bass", s.bass)
            .putInt("virt", s.virtualizer)
            .putString("spatial", s.spatial.name)
            .putString("skin", s.skin)
            .putString("spectrum", s.spectrum.name)
            .putFloat("sgain", s.spectrumGain)
            .putString("hero", s.hero)
            .putString("custom", s.custom.entries.joinToString(";") { it.key + "=" + it.value.joinToString(",") })
            .apply()
    }
}
