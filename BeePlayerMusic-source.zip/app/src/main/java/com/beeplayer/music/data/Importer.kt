package com.beeplayer.music.data

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Impor file / folder musik lewat pemilih dokumen Android (SAF). */
object Importer {
    private val audioExt = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma", "amr", "mid", "mka")

    suspend fun importFiles(ctx: Context, uris: List<Uri>, onProgress: (Int) -> Unit): Int =
        withContext(Dispatchers.IO) {
            val out = mutableListOf<Track>()
            for (u in uris) {
                runCatching {
                    ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val name = DocumentFile.fromSingleUri(ctx, u)?.name
                readTrack(ctx, u, name)?.let { out += it }
                onProgress(out.size)
            }
            LibraryStore.addImported(out)
            out.size
        }

    suspend fun importTree(ctx: Context, tree: Uri, onProgress: (Int) -> Unit): Int =
        withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val root = DocumentFile.fromTreeUri(ctx, tree) ?: return@withContext 0
            val out = mutableListOf<Track>()
            walk(ctx, root, out, onProgress)
            LibraryStore.addImported(out)
            out.size
        }

    private fun walk(ctx: Context, dir: DocumentFile, out: MutableList<Track>, onProgress: (Int) -> Unit) {
        val children = try { dir.listFiles() } catch (_: Exception) { return }
        for (f in children) {
            if (f.isDirectory) {
                walk(ctx, f, out, onProgress)
            } else if (f.isFile && isAudio(f)) {
                readTrack(ctx, f.uri, f.name)?.let { out += it }
                onProgress(out.size)
            }
        }
    }

    private fun isAudio(f: DocumentFile): Boolean {
        val type = f.type ?: ""
        if (type.startsWith("audio/")) return true
        val ext = f.name?.substringAfterLast('.', "")?.lowercase() ?: ""
        return ext in audioExt
    }

    private fun readTrack(ctx: Context, uri: Uri, displayName: String?): Track? {
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(ctx, uri)
            val id = "F:" + uri.toString().hashCode().toUInt().toString(16)
            val title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
                ?: displayName?.substringBeforeLast('.') ?: "Tanpa judul"
            val artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }
                ?: "Artis tidak diketahui"
            val album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: ""
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val no = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER)
                ?.substringBefore('/')?.trim()?.toIntOrNull() ?: 0
            var art: String? = null
            val pic = mmr.embeddedPicture
            if (pic != null) {
                val dir = File(ctx.filesDir, "art").apply { mkdirs() }
                val f = File(dir, "$id.jpg".replace(":", "_"))
                f.writeBytes(pic)
                art = Uri.fromFile(f).toString()
            }
            Track(id, title, artist, album, uri.toString(), art, dur, no, Source.LOCAL, null)
        } catch (_: Exception) {
            null
        } finally {
            runCatching { mmr.release() }
        }
    }
}
