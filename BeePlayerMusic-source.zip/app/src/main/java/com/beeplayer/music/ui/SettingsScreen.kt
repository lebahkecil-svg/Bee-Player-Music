package com.beeplayer.music.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.beeplayer.music.data.SettingsStore
import com.beeplayer.music.data.SpectrumStyle
import com.beeplayer.music.service.PlayerController
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Semua pengaturan: suara & preamp, skin spektrum, tema warna, timer tidur. */
@Composable
fun SettingsScreen(skin: Skin) {
    val s by SettingsStore.state.collectAsState()
    val ui by PlayerController.ui.collectAsState()
    val sleepEndState by PlayerController.sleepEnd.collectAsState()
    val sleepEnd = sleepEndState

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Suara", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SoundSettings()

        HorizontalDivider()
        Text("Skin spektrum", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Gerak spektrum mengikuti level (dB) musik yang sedang diputar. Ketuk untuk memilih gaya.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SpectrumStyle.values().toList().chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { st ->
                        SpectrumTile(
                            st, st == s.spectrum, skin, Modifier.weight(1f)
                        ) { SettingsStore.update { it.copy(spectrum = st) } }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        SectionTitle("Sensitivitas spektrum   ${"%.1f".format(s.spectrumGain)}x")
        Slider(
            value = s.spectrumGain, valueRange = 0.5f..2f,
            onValueChange = { v -> SettingsStore.update { it.copy(spectrumGain = (Math.round(v * 10) / 10f)) } }
        )
        SectionTitle("Tampilan layar Sedang Diputar")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = s.hero != "spectrum",
                onClick = { SettingsStore.update { it.copy(hero = "cover") } },
                label = { Text("Sampul + spektrum kecil") }
            )
            FilterChip(
                selected = s.hero == "spectrum",
                onClick = { SettingsStore.update { it.copy(hero = "spectrum") } },
                label = { Text("Spektrum besar") }
            )
        }

        HorizontalDivider()
        Text("Tema warna", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Skins.all.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { sk ->
                        ThemeTile(sk, sk.name == s.skin, Modifier.weight(1f)) {
                            SettingsStore.update { it.copy(skin = sk.name) }
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        HorizontalDivider()
        Text("Timer tidur", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0, 15, 30, 45, 60, 90).forEach { m ->
                FilterChip(
                    selected = m == 0 && sleepEnd == null,
                    onClick = { PlayerController.setSleepTimer(m) },
                    label = { Text(if (m == 0) "Mati" else "$m menit") }
                )
            }
        }
        if (sleepEnd != null) {
            Text(
                "Musik berhenti otomatis pukul " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(sleepEnd)),
                color = MaterialTheme.colorScheme.primary
            )
        }

        HorizontalDivider()
        Text("Tentang", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(
            "Bee Player Music v1.0\nPemutar musik dengan preamp, equalizer, keluaran Mono/Stereo/3D/4D, " +
                    "putar mundur, daftar putar, favorit, dan spektrum bergerak.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SpectrumTile(style: SpectrumStyle, selected: Boolean, skin: Skin, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .height(120.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(skin.bgTop, skin.bgBottom)))
            .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) skin.accent else skin.text.copy(alpha = 0.25f)), shape)
            .clickable(onClick = onClick)
    ) {
        SpectrumView(
            style, skin.accent, skin.accent2, false, 1f,
            Modifier.fillMaxSize().padding(start = 10.dp, top = 10.dp, end = 10.dp, bottom = 30.dp),
            demo = true
        )
        Text(
            if (selected) style.label + " ✓" else style.label,
            color = skin.text, fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
        )
    }
}

@Composable
private fun ThemeTile(sk: Skin, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .height(90.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(sk.bgTop, sk.bgBottom)))
            .border(BorderStroke(if (selected) 3.dp else 1.dp, if (selected) sk.accent else sk.text.copy(alpha = 0.3f)), shape)
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Row(Modifier.align(Alignment.TopStart), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.size(20.dp).clip(CircleShape).background(sk.accent))
            Box(Modifier.size(20.dp).clip(CircleShape).background(sk.accent2))
            Box(Modifier.size(20.dp).clip(CircleShape).background(sk.surface))
        }
        Text(
            if (selected) "${sk.name} ✓" else sk.name, color = sk.text, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.BottomStart)
        )
    }
}
