package com.beeplayer.music

import android.app.Application
import com.beeplayer.music.data.SettingsStore
import com.beeplayer.music.service.PlayerController

class BeeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        com.beeplayer.music.data.LibraryStore.init(this)
        PlayerController.init(this)
        PlayerController.connect()
    }
}
