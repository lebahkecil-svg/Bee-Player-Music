package com.beeplayer.music.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object LocalLibrary {
    suspend fun load(ctx: Context): List<Track> = withContext(Dispatchers.IO) {
        val list = mutableListOf<Track>()
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.TRACK, MediaStore.Audio.Media.DATA
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"
        try {
            ctx.contentResolver.query(
                collection, proj, sel, null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val albumId = c.getLong(iAlbumId)
                    val artBase = if (Build.VERSION.SDK_INT >= 29) "content://media/external/audio/albums"
                    else "content://media/external/audio/albumart"
                    val art = ContentUris.withAppendedId(Uri.parse(artBase), albumId).toString()
                    val artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: "Artis tidak diketahui"
                    list += Track(
                        id = "L:$id",
                        title = c.getString(iTitle) ?: "Tanpa judul",
                        artist = artist,
                        album = c.getString(iAlbum) ?: "",
                        uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id).toString(),
                        artUri = art,
                        durationMs = c.getLong(iDur),
                        trackNo = c.getInt(iTrack) % 1000,
                        source = Source.LOCAL,
                        path = c.getString(iData)
                    )
                }
            }
        } catch (_: Exception) { }
        list
    }
}
