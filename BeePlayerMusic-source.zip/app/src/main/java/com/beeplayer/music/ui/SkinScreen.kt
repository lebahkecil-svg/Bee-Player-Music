package com.beeplayer.music.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.beeplayer.music.data.SettingsStore

@Composable
fun SkinScreen() {
    val s by SettingsStore.state.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Pilih Skin", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(Skins.all) { sk ->
                val selected = sk.name == s.skin
                Box(
                    Modifier.fillMaxWidth().height(120.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(sk.bgTop, sk.bgBottom)))
                        .border(
                            BorderStroke(if (selected) 3.dp else 1.dp, if (selected) sk.accent else sk.text.copy(alpha = 0.3f)),
                            RoundedCornerShape(18.dp)
                        )
                        .clickable { SettingsStore.update { it.copy(skin = sk.name) } }
                        .padding(14.dp)
                ) {
                    Row(Modifier.align(Alignment.TopStart), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(22.dp).clip(CircleShape).background(sk.accent))
                        Box(Modifier.size(22.dp).clip(CircleShape).background(sk.surface))
                    }
                    Text(
                        if (selected) "${sk.name} ✓" else sk.name, color = sk.text, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.align(Alignment.BottomStart)
                    )
                }
            }
        }
    }
}
