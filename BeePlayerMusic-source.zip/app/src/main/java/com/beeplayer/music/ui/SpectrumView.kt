package com.beeplayer.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import com.beeplayer.music.audio.SpectrumBus
import com.beeplayer.music.data.SpectrumStyle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private fun demoBands(nanos: Long): FloatArray {
    val t = nanos / 1_000_000_000.0
    return FloatArray(SpectrumBus.BANDS) { i ->
        val base = 0.5 + 0.5 * sin(t * (1.6 + i * 0.11) + i * 0.7)
        val slope = 1.0 - i / (SpectrumBus.BANDS * 1.5)
        (base * slope).toFloat().coerceIn(0f, 1f)
    }
}

/**
 * Visualisasi spektrum yang bergerak mengikuti level (dB) musik yang sedang diputar.
 * demo = true memakai data sintetis (untuk pratinjau gaya).
 */
@Composable
fun SpectrumView(
    style: SpectrumStyle,
    c1: Color,
    c2: Color,
    playing: Boolean,
    gain: Float,
    modifier: Modifier = Modifier,
    demo: Boolean = false
) {
    val n = SpectrumBus.BANDS
    val smooth = remember { FloatArray(n) }
    val peaks = remember { FloatArray(n) }
    var tick by remember { mutableLongStateOf(0L) }
    var rot by remember { mutableFloatStateOf(0f) }
    val playingNow by rememberUpdatedState(playing)
    val gainNow by rememberUpdatedState(gain)

    LaunchedEffect(demo) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
            last = now
            val src = if (demo) demoBands(now) else SpectrumBus.bands
            for (i in 0 until n) {
                val target = if (playingNow || demo) (src[i] * gainNow).coerceIn(0f, 1f) else 0f
                val s = smooth[i]
                smooth[i] = if (target > s) s + (target - s) * min(1f, dt * 18f)
                else s + (target - s) * min(1f, dt * 5f)
                peaks[i] = max(smooth[i], peaks[i] - dt * 0.45f)
            }
            rot = (rot + dt * 14f) % 360f
            tick = now
        }
    }

    Canvas(modifier) {
        if (tick < 0L) return@Canvas // membaca state agar digambar ulang tiap frame
        when (style) {
            SpectrumStyle.BARS -> drawBars(smooth, peaks, c1, c2)
            SpectrumStyle.MIRROR -> drawMirror(smooth, c1, c2)
            SpectrumStyle.CIRCLE -> drawCircleSpectrum(smooth, c1, c2, rot)
            SpectrumStyle.WAVE -> drawWave(smooth, c1, c2)
            SpectrumStyle.DOTS -> drawDots(smooth, c1, c2)
            SpectrumStyle.BLOCKS -> drawBlocks(smooth, peaks, c1, c2)
            SpectrumStyle.PULSE -> drawPulse(smooth, c1, c2)
        }
    }
}

private fun DrawScope.drawBars(v: FloatArray, peaks: FloatArray, c1: Color, c2: Color) {
    val n = v.size
    val bw = size.width / n
    val gap = bw * 0.22f
    val maxH = size.height * 0.96f
    for (i in 0 until n) {
        val h = max(v[i] * maxH, 3f)
        val x = i * bw + gap / 2
        drawRoundRect(
            color = lerp(c1, c2, v[i]),
            topLeft = Offset(x, size.height - h),
            size = Size(bw - gap, h),
            cornerRadius = CornerRadius((bw - gap) / 2)
        )
        val py = size.height - max(peaks[i] * maxH, 3f) - 6f
        drawRoundRect(
            color = c2,
            topLeft = Offset(x, py),
            size = Size(bw - gap, 3f),
            cornerRadius = CornerRadius(1.5f)
        )
    }
}

private fun DrawScope.drawMirror(v: FloatArray, c1: Color, c2: Color) {
    val n = v.size
    val total = n * 2
    val bw = size.width / total
    val gap = bw * 0.25f
    val cy = size.height / 2
    for (k in 0 until total) {
        val idx = if (k < n) n - 1 - k else k - n
        val h = max(v[idx] * size.height * 0.48f, 2f)
        drawRoundRect(
            color = lerp(c1, c2, v[idx]),
            topLeft = Offset(k * bw + gap / 2, cy - h),
            size = Size(bw - gap, h * 2),
            cornerRadius = CornerRadius((bw - gap) / 2)
        )
    }
}

private fun DrawScope.drawCircleSpectrum(v: FloatArray, c1: Color, c2: Color, rot: Float) {
    val n = v.size
    val total = n * 2
    val c = center
    val m = min(size.width, size.height)
    val r0 = m * 0.22f
    val maxLen = m * 0.26f
    drawCircle(c1.copy(alpha = 0.18f), r0 - 4f, c)
    drawCircle(c2.copy(alpha = 0.6f), r0 - 4f, c, style = Stroke(2f))
    for (k in 0 until total) {
        val idx = if (k < n) n - 1 - k else k - n
        val a = Math.toRadians((rot + k * 360.0 / total)).toFloat()
        val len = 4f + v[idx] * maxLen
        val cx = cos(a)
        val sy = sin(a)
        drawLine(
            color = lerp(c1, c2, v[idx]),
            start = Offset(c.x + cx * r0, c.y + sy * r0),
            end = Offset(c.x + cx * (r0 + len), c.y + sy * (r0 + len)),
            strokeWidth = max(3f, m / total * 1.4f),
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawWave(v: FloatArray, c1: Color, c2: Color) {
    val n = v.size
    val cy = size.height / 2
    val dx = size.width / (n - 1)
    for (dir in intArrayOf(-1, 1)) {
        val path = Path()
        path.moveTo(0f, cy)
        var px = 0f
        var py = cy + dir * v[0] * size.height * 0.46f
        path.lineTo(px, py)
        for (i in 1 until n) {
            val x = i * dx
            val y = cy + dir * v[i] * size.height * 0.46f
            val mx = (px + x) / 2
            path.cubicTo(mx, py, mx, y, x, y)
            px = x
            py = y
        }
        path.lineTo(size.width, cy)
        path.close()
        val top = if (dir < 0) 0f else cy
        val bottom = if (dir < 0) cy else size.height
        val brush = if (dir < 0)
            Brush.verticalGradient(listOf(c2.copy(alpha = 0.85f), c1.copy(alpha = 0.15f)), startY = top, endY = bottom)
        else
            Brush.verticalGradient(listOf(c1.copy(alpha = 0.15f), c2.copy(alpha = 0.85f)), startY = top, endY = bottom)
        drawPath(path, brush)
        drawPath(path, c2, style = Stroke(width = 3f))
    }
}

private fun DrawScope.drawDots(v: FloatArray, c1: Color, c2: Color) {
    val n = v.size
    val rows = 12
    val cw = size.width / n
    val rh = size.height / rows
    val r = min(cw, rh) * 0.34f
    for (i in 0 until n) {
        val lit = (v[i] * rows).toInt()
        for (j in 0 until rows) {
            val cx = i * cw + cw / 2
            val cy = size.height - j * rh - rh / 2
            if (j < lit) drawCircle(lerp(c1, c2, j / rows.toFloat()), r, Offset(cx, cy))
            else drawCircle(c1.copy(alpha = 0.10f), r * 0.8f, Offset(cx, cy))
        }
    }
}

private fun DrawScope.drawBlocks(v: FloatArray, peaks: FloatArray, c1: Color, c2: Color) {
    val n = v.size
    val segs = 16
    val bw = size.width / n
    val sh = size.height / segs
    val gx = bw * 0.18f
    val gy = sh * 0.22f
    for (i in 0 until n) {
        val lit = (v[i] * segs).toInt()
        val peak = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
        for (s in 0 until segs) {
            val color = when {
                s < lit -> lerp(c1, c2, s / segs.toFloat())
                s == peak && peak >= lit -> c2
                else -> c1.copy(alpha = 0.08f)
            }
            drawRect(
                color = color,
                topLeft = Offset(i * bw + gx / 2, size.height - (s + 1) * sh + gy / 2),
                size = Size(bw - gx, sh - gy)
            )
        }
    }
}

private fun DrawScope.drawPulse(v: FloatArray, c1: Color, c2: Color) {
    val c = center
    val m = min(size.width, size.height)
    var low = 0f
    for (i in 0 until 4) low += v[i]
    low /= 4f
    var all = 0f
    for (x in v) all += x
    all /= v.size
    val core = m * (0.12f + low * 0.16f)
    drawCircle(
        brush = Brush.radialGradient(listOf(c2, c1.copy(alpha = 0.0f)), center = c, radius = core * 2.2f),
        radius = core * 2.2f, center = c
    )
    drawCircle(lerp(c1, c2, low), core, c)
    for (ring in 1..4) {
        val rr = core + ring * m * 0.07f + all * m * 0.10f * ring
        drawCircle(
            color = lerp(c1, c2, ring / 4f).copy(alpha = 0.65f - ring * 0.13f),
            radius = rr, center = c, style = Stroke(width = 2f + (5 - ring) * 1.6f)
        )
    }
}
