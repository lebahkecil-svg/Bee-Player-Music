package com.beeplayer.music.service

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.beeplayer.music.audio.ReverseDecoder
import com.beeplayer.music.data.Source
import com.beeplayer.music.data.Track
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlayerUi(
    val queue: List<Track> = emptyList(),
    val index: Int = -1,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val reverse: Boolean = false,
    val reverseLoading: Boolean = false,
    val buffering: Boolean = false,
    val message: String? = null
) {
    val current: Track? get() = queue.getOrNull(index)
}

/** Jembatan UI ↔ layanan pemutar (hidup selama proses aplikasi hidup). */
object PlayerController {
    private lateinit var app: Context
    private var controller: MediaController? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val pending = mutableListOf<(MediaController) -> Unit>()
    private val known = HashMap<String, Track>()
    private var queue: List<Track> = emptyList()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()
    private val _pos = MutableStateFlow(0L)
    val positionMs: StateFlow<Long> = _pos.asStateFlow()

    fun init(ctx: Context) {
        app = ctx.applicationContext
    }

    fun connect() {
        if (controller != null) return
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(listener)
                sync()
                pending.toList().forEach { it(c) }
                pending.clear()
            } catch (_: Exception) {
                _ui.update { it.copy(message = "Gagal terhubung ke layanan pemutar") }
            }
        }, MoreExecutors.directExecutor())

        scope.launch {
            while (isActive) {
                val c = controller
                if (c != null && c.mediaItemCount > 0) _pos.value = c.currentPosition
                delay(if (_ui.value.isPlaying) 66 else 300)
            }
        }
    }

    private fun whenReady(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else {
            pending += block
            connect()
        }
    }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (_ui.value.reverse && mediaItem != null && !isReversed(mediaItem)) {
                scope.launch { reverseCurrent() }
            }
        }
    }

    private fun isReversed(item: MediaItem) = ReverseDecoder.isReversedFile(item.localConfiguration?.uri)

    private fun trackFrom(item: MediaItem): Track = known[item.mediaId] ?: Track(
        id = item.mediaId,
        title = item.mediaMetadata.title?.toString() ?: "Tanpa judul",
        artist = item.mediaMetadata.artist?.toString() ?: "",
        album = item.mediaMetadata.albumTitle?.toString() ?: "",
        uri = item.localConfiguration?.uri?.toString() ?: "",
        artUri = item.mediaMetadata.artworkUri?.toString(),
        durationMs = 0,
        trackNo = item.mediaMetadata.trackNumber ?: 0,
        source = Source.LOCAL
    )

    private fun sync() {
        val c = controller ?: return
        val n = c.mediaItemCount
        if (queue.size != n || (0 until n).any { queue[it].id != c.getMediaItemAt(it).mediaId }) {
            queue = (0 until n).map { trackFrom(c.getMediaItemAt(it)) }
        }
        val idx = if (n == 0) -1 else c.currentMediaItemIndex
        val dur = c.duration.takeIf { it > 0 } ?: queue.getOrNull(idx)?.durationMs ?: 0L
        _ui.update {
            it.copy(
                queue = queue, index = idx, isPlaying = c.isPlaying, durationMs = dur,
                shuffle = c.shuffleModeEnabled, repeat = c.repeatMode,
                buffering = c.playbackState == Player.STATE_BUFFERING
            )
        }
    }

    private fun item(t: Track): MediaItem = MediaItem.Builder()
        .setMediaId(t.id)
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                .setArtworkUri(t.artUri?.let { Uri.parse(it) })
                .setTrackNumber(t.trackNo)
                .build()
        ).build()

    // ---------- kontrol ----------

    fun playQueue(tracks: List<Track>, start: Int) {
        if (tracks.isEmpty()) return
        tracks.forEach { known[it.id] = it }
        queue = tracks
        _ui.update { it.copy(queue = tracks, index = start, message = null) }
        whenReady { c ->
            c.setMediaItems(tracks.map(::item), start, 0)
            c.prepare()
            c.play()
            sync()
            if (_ui.value.reverse) scope.launch { reverseCurrent() }
        }
    }

    fun playIndex(i: Int) = whenReady { c -> c.seekTo(i, 0); c.play() }
    fun togglePlay() = whenReady { c -> if (c.isPlaying) c.pause() else { if (c.playbackState == Player.STATE_ENDED) c.seekTo(0); c.play() } }
    fun next() = whenReady { it.seekToNextMediaItem() }
    fun previous() = whenReady { c -> if (c.currentPosition > 3000) c.seekTo(0) else c.seekToPreviousMediaItem() }
    fun seekTo(ms: Long) = whenReady { c -> c.seekTo(ms.coerceAtLeast(0)); _pos.value = ms }
    fun toggleShuffle() = whenReady { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    fun cycleRepeat() = whenReady {
        it.repeatMode = when (it.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun clearMessage() = _ui.update { it.copy(message = null) }

    // ---------- putar mundur ----------

    fun setReverse(on: Boolean) {
        _ui.update { it.copy(reverse = on) }
        whenReady { scope.launch { if (on) reverseCurrent() else restoreCurrent() } }
    }

    private suspend fun reverseCurrent() {
        val c = controller ?: return
        val cur = c.currentMediaItem ?: return
        if (isReversed(cur)) return
        val t = known[cur.mediaId] ?: trackFrom(cur)
        _ui.update { it.copy(reverseLoading = true) }
        val file = try { ReverseDecoder.reverse(app, t) } catch (_: Exception) { null }
        _ui.update { it.copy(reverseLoading = false) }
        if (file == null) {
            _ui.update { it.copy(reverse = false, message = "Lagu ini tidak bisa diputar mundur (terlalu panjang / format tidak didukung)") }
            return
        }
        if (!_ui.value.reverse || c.currentMediaItem?.mediaId != t.id) return
        val dur = c.duration.takeIf { it > 0 } ?: t.durationMs
        val newPos = (dur - c.currentPosition).coerceAtLeast(0)
        replaceCurrent(c, cur.buildUpon().setUri(Uri.fromFile(file)).build(), newPos)
    }

    private fun restoreCurrent() {
        val c = controller ?: return
        val cur = c.currentMediaItem ?: return
        if (!isReversed(cur)) return
        val t = known[cur.mediaId] ?: return
        val dur = c.duration.takeIf { it > 0 } ?: t.durationMs
        val newPos = (dur - c.currentPosition).coerceAtLeast(0)
        replaceCurrent(c, item(t), newPos)
    }

    private fun replaceCurrent(c: MediaController, newItem: MediaItem, pos: Long) {
        val i = c.currentMediaItemIndex
        c.replaceMediaItem(i, newItem)
        c.seekTo(i, pos)
    }
}
