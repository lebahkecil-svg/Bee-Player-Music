package com.beeplayer.music.data

enum class Source { LOCAL, ONLINE }

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val uri: String,
    val artUri: String?,
    val durationMs: Long,
    val trackNo: Int,
    val source: Source,
    val path: String? = null
)

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
