package com.beeplayer.music.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.beeplayer.music.data.Track
import com.beeplayer.music.data.formatTime
import com.beeplayer.music.service.PlayerController
import kotlin.math.PI
import kotlin.math.sin

/** Piringan hitam yang berputar selama lagu diputar. */
@Composable
fun VinylDisk(spinning: Boolean, accent: Color, modifier: Modifier = Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(spinning) {
        if (spinning) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                angle = (angle + (now - last) / 1_000_000_000f * 100f) % 360f // ~16 rpm
                last = now
            }
        }
    }
    Canvas(modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension / 2
        rotate(angle, pivot = c) {
            drawCircle(Color(0xFF0C0C0C), r, c)
            var rr = r * 0.97f
            while (rr > r * 0.40f) {
                drawCircle(Color(0xFF262626), rr, c, style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f))
                rr -= r * 0.035f
            }
            drawCircle(
                brush = Brush.sweepGradient(
                    listOf(
                        Color.Transparent, Color.White.copy(alpha = 0.16f), Color.Transparent,
                        Color.Transparent, Color.White.copy(alpha = 0.16f), Color.Transparent
                    ), c
                ),
                radius = r, center = c
            )
            drawCircle(accent, r * 0.34f, c)
            drawCircle(Color.Black.copy(alpha = 0.25f), r * 0.34f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
            drawCircle(Color.Black.copy(alpha = 0.55f), r * 0.20f, c, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
            drawCircle(Color(0xFF0C0C0C), r * 0.045f, c)
        }
    }
}

/** Bilah progres berupa titik-titik; gelombang titik berjalan menuju posisi saat ini. Bisa digeser untuk seek. */
@Composable
fun DotProgress(
    positionMs: Long, durationMs: Long, playing: Boolean,
    accent: Color, dim: Color, onSeek: (Long) -> Unit, modifier: Modifier = Modifier
) {
    val inf = rememberInfiniteTransition(label = "dots")
    val t by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "wave"
    )
    val pulse by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse), label = "pulse"
    )
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = drag ?: if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    Canvas(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .pointerInput(durationMs) {
                detectTapGestures { o -> onSeek((o.x / size.width * durationMs).toLong()) }
            }
            .pointerInput(durationMs) {
                detectHorizontalDragGestures(
                    onDragStart = { drag = (it.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { drag?.let { f -> onSeek((f * durationMs).toLong()) }; drag = null },
                    onDragCancel = { drag = null },
                    onHorizontalDrag = { ch, _ -> drag = (ch.position.x / size.width).coerceIn(0f, 1f) }
                )
            }
    ) {
        val pad = 10.dp.toPx()
        val w = size.width - pad * 2
        val n = (w / 12.dp.toPx()).toInt().coerceAtLeast(12)
        val step = w / n
        val cy = size.height / 2
        val headX = pad + w * frac
        for (i in 0..n) {
            val x = pad + step * i
            val played = x <= headX
            if (played) {
                val wave = if (playing) (sin((i * 0.5f - t * 2f * PI.toFloat() * 1f)) * 0.5f + 0.5f) else 0.4f
                val rad = 2.6.dp.toPx() + wave * 2.2.dp.toPx()
                drawCircle(accent.copy(alpha = 0.55f + 0.45f * wave), rad, Offset(x, cy))
            } else {
                drawCircle(dim, 2.4.dp.toPx(), Offset(x, cy))
            }
        }
        // titik kepala: berdenyut
        val hr = 7.dp.toPx() + (if (playing) pulse * 2.dp.toPx() else 0f)
        drawCircle(accent.copy(alpha = 0.25f), hr * 1.9f, Offset(headX, cy))
        drawCircle(accent, hr, Offset(headX, cy))
        drawCircle(Color.White.copy(alpha = 0.85f), hr * 0.35f, Offset(headX, cy))
    }
}

@Composable
fun CoverThumb(art: String?, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.MusicNote, null, tint = MaterialTheme.colorScheme.primary)
        if (art != null) AsyncImage(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
fun TrackRow(track: Track, current: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CoverThumb(track.artUri, 52.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.SemiBold,
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                listOf(track.artist, track.album).filter { it.isNotBlank() }.joinToString(" • "),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            if (track.durationMs > 0) Text(formatTime(track.durationMs), style = MaterialTheme.typography.labelMedium)
            if (track.trackNo > 0) Text("Trek ${track.trackNo}", style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun MiniPlayer(onOpen: () -> Unit) {
    val ui by PlayerController.ui.collectAsState()
    val pos by PlayerController.positionMs.collectAsState()
    val t = ui.current ?: return
    Surface(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onOpen),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp
    ) {
        Column {
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                CoverThumb(t.artUri, 44.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { PlayerController.togglePlay() }) {
                    Icon(if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Putar/Jeda")
                }
                IconButton(onClick = { PlayerController.next() }) { Icon(Icons.Rounded.SkipNext, "Berikutnya") }
            }
            LinearProgressIndicator(
                progress = { if (ui.durationMs > 0) (pos.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth().height(2.dp)
            )
        }
    }
}
