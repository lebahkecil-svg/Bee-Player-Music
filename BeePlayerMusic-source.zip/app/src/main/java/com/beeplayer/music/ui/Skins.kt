package com.beeplayer.music.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class Skin(
    val name: String,
    val dark: Boolean,
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
    val accent: Color,
    val text: Color
)

object Skins {
    val all = listOf(
        Skin("Madu", true, Color(0xFF1A1405), Color(0xFF0A0804), Color(0xFF2A2108), Color(0xFFFFC107), Color(0xFFFFF3D6)),
        Skin("Neon Malam", true, Color(0xFF0B0B1E), Color(0xFF1A0B33), Color(0xFF1E1B3F), Color(0xFF00E5FF), Color(0xFFEDEBFF)),
        Skin("Samudra", true, Color(0xFF021B2B), Color(0xFF03324D), Color(0xFF07435F), Color(0xFF4DD0E1), Color(0xFFE0F7FA)),
        Skin("Hutan", true, Color(0xFF0B1F12), Color(0xFF123524), Color(0xFF1B4A2F), Color(0xFF8BC34A), Color(0xFFE8F5E9)),
        Skin("Senja", true, Color(0xFF2B0F1A), Color(0xFF4A1C2A), Color(0xFF5C2735), Color(0xFFFF7043), Color(0xFFFFE9E0)),
        Skin("Retro Vinyl", true, Color(0xFF2D1B0E), Color(0xFF3E2723), Color(0xFF5D4037), Color(0xFFFFB74D), Color(0xFFFFF1DC)),
        Skin("AMOLED", true, Color(0xFF000000), Color(0xFF000000), Color(0xFF141414), Color(0xFFB388FF), Color(0xFFFFFFFF)),
        Skin("Sakura", false, Color(0xFFFFF0F4), Color(0xFFFFD9E3), Color(0xFFFFFFFF), Color(0xFFE91E63), Color(0xFF3B1620)),
        Skin("Kertas", false, Color(0xFFFAF7F0), Color(0xFFEDE6D6), Color(0xFFFFFFFF), Color(0xFF6D4C41), Color(0xFF2B2118))
    )

    fun byName(n: String): Skin = all.firstOrNull { it.name == n } ?: all.first()
}

@Composable
fun BeeTheme(skin: Skin, content: @Composable () -> Unit) {
    val scheme = if (skin.dark) darkColorScheme(
        primary = skin.accent, onPrimary = skin.bgBottom,
        secondary = skin.accent, background = skin.bgBottom, onBackground = skin.text,
        surface = skin.surface, onSurface = skin.text, surfaceVariant = skin.surface,
        onSurfaceVariant = skin.text.copy(alpha = 0.75f), outline = skin.text.copy(alpha = 0.3f)
    ) else lightColorScheme(
        primary = skin.accent, onPrimary = Color.White,
        secondary = skin.accent, background = skin.bgBottom, onBackground = skin.text,
        surface = skin.surface, onSurface = skin.text, surfaceVariant = skin.surface,
        onSurfaceVariant = skin.text.copy(alpha = 0.75f), outline = skin.text.copy(alpha = 0.3f)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
