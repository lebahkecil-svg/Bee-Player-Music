package com.beeplayer.music.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder

data class LyricLine(val timeMs: Long, val text: String)
data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

/** Lirik: file .lrc di samping lagu (jika terbaca), lalu LRCLIB (gratis, tanpa API key). */
object LyricsRepo {
    private val cache = HashMap<String, Lyrics?>()
    private val stamp = Regex("\\[(\\d+):(\\d+(?:\\.\\d+)?)]")

    suspend fun fetch(t: Track): Lyrics? = withContext(Dispatchers.IO) {
        if (cache.containsKey(t.id)) return@withContext cache[t.id]
        var result: Lyrics? = null
        try {
            t.path?.let { p ->
                val f = File(p.substringBeforeLast('.') + ".lrc")
                if (f.exists()) result = parse(f.readText(), null)
            }
        } catch (_: Exception) { }
        if (result == null) result = runCatching { fromLrclib(t) }.getOrNull()
        cache[t.id] = result
        result
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun fromLrclib(t: Track): Lyrics? {
        val title = t.title.replace(Regex("\\(.*?\\)|\\[.*?]"), "").trim()
        val artist = t.artist.takeIf { !it.startsWith("Artis tidak") } ?: ""
        var obj: JSONObject? = try {
            OnlineSource.httpGet(
                "https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}" +
                        "&duration=${t.durationMs / 1000}"
            ).let(::JSONObject)
        } catch (_: Exception) { null }
        if (obj == null) {
            val arr = JSONArray(OnlineSource.httpGet("https://lrclib.net/api/search?q=${enc("$artist $title".trim())}"))
            if (arr.length() > 0) obj = arr.getJSONObject(0)
        }
        obj ?: return null
        val synced = obj.optString("syncedLyrics", "")
        val plain = obj.optString("plainLyrics", "")
        return when {
            synced.isNotBlank() -> parse(synced, null)
            plain.isNotBlank() -> parse(null, plain)
            else -> null
        }
    }

    private fun parse(lrc: String?, plain: String?): Lyrics? {
        if (lrc != null) {
            val lines = mutableListOf<LyricLine>()
            for (raw in lrc.lines()) {
                val ms = stamp.findAll(raw).toList()
                if (ms.isEmpty()) continue
                val text = raw.replace(stamp, "").trim()
                for (m in ms) {
                    val t = ((m.groupValues[1].toLong() * 60 + 0.0 + m.groupValues[2].toDouble()) * 1000).toLong()
                    lines += LyricLine(t, text)
                }
            }
            if (lines.isNotEmpty()) return Lyrics(lines.sortedBy { it.timeMs }, true)
        }
        val src = plain ?: lrc ?: return null
        val lines = src.lines().map { LyricLine(-1, it.trim()) }
        return if (lines.any { it.text.isNotEmpty() }) Lyrics(lines, false) else null
    }
}
