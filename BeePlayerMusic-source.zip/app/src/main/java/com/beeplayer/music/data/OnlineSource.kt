package com.beeplayer.music.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Pencarian lagu online tanpa API key:
 *  1. Audius  – lagu penuh (musik independen, gratis & legal)
 *  2. iTunes  – cadangan, cuplikan 30 detik
 */
object OnlineSource {
    private const val APP = "BeePlayerMusic"
    private var hosts: List<String> = emptyList()

    fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "BeePlayerMusic/1.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    suspend fun search(query: String): List<Track> = withContext(Dispatchers.IO) {
        val q = query.trim()
        if (q.isEmpty()) return@withContext emptyList()
        val a = runCatching { searchAudius(q) }.getOrDefault(emptyList())
        if (a.isNotEmpty()) a else runCatching { searchItunes(q) }.getOrDefault(emptyList())
    }

    private fun audiusHosts(): List<String> {
        if (hosts.isEmpty()) {
            val arr = JSONObject(httpGet("https://api.audius.co")).getJSONArray("data")
            hosts = (0 until arr.length()).map { arr.getString(it) }.shuffled().take(4)
        }
        return hosts
    }

    private fun searchAudius(q: String): List<Track> {
        for (host in audiusHosts()) {
            try {
                val json = JSONObject(httpGet("$host/v1/tracks/search?query=${enc(q)}&limit=40&app_name=$APP"))
                val data = json.getJSONArray("data")
                val out = mutableListOf<Track>()
                for (i in 0 until data.length()) {
                    val o = data.getJSONObject(i)
                    if (o.has("is_streamable") && !o.optBoolean("is_streamable", true)) continue
                    val id = o.getString("id")
                    val art = o.optJSONObject("artwork")?.let {
                        it.optString("480x480").ifEmpty { it.optString("150x150") }
                    }?.takeIf { it.isNotEmpty() }
                    out += Track(
                        id = "A:$id",
                        title = o.optString("title", "Tanpa judul"),
                        artist = o.optJSONObject("user")?.optString("name") ?: "Audius",
                        album = "Audius",
                        uri = "$host/v1/tracks/$id/stream?app_name=$APP",
                        artUri = art,
                        durationMs = o.optLong("duration", 0) * 1000,
                        trackNo = i + 1,
                        source = Source.ONLINE
                    )
                }
                return out
            } catch (_: Exception) {
                // coba host berikutnya
            }
        }
        hosts = emptyList()
        return emptyList()
    }

    private fun searchItunes(q: String): List<Track> {
        val json = JSONObject(httpGet("https://itunes.apple.com/search?term=${enc(q)}&media=music&entity=song&limit=30"))
        val r = json.getJSONArray("results")
        val out = mutableListOf<Track>()
        for (i in 0 until r.length()) {
            val o = r.getJSONObject(i)
            val prev = o.optString("previewUrl")
            if (prev.isEmpty()) continue
            out += Track(
                id = "I:${o.optLong("trackId")}",
                title = o.optString("trackName", "Tanpa judul"),
                artist = o.optString("artistName", ""),
                album = o.optString("collectionName", "") + " (cuplikan 30 dtk)",
                uri = prev,
                artUri = o.optString("artworkUrl100").replace("100x100", "600x600").ifEmpty { null },
                durationMs = 30000,
                trackNo = o.optInt("trackNumber", i + 1),
                source = Source.ONLINE
            )
        }
        return out
    }
}
