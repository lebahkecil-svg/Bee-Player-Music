package com.beeplayer.music.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Hasil analisis spektrum terbaru (0..1 per pita), diisi dari thread audio, dibaca UI. */
object SpectrumBus {
    const val BANDS = 32
    @Volatile var bands: FloatArray = FloatArray(BANDS)
}

/** FFT 2048 titik dengan overlap 50%, menghasilkan 32 pita berskala log (≈40 Hz–16 kHz). */
class SpectrumAnalyzer(private val sampleRate: Int) {
    private val n = 2048
    private val buf = FloatArray(n)
    private var fill = 0
    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val window = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { (-sin(2.0 * PI * it / n)).toFloat() }
    private val edges = IntArray(SpectrumBus.BANDS + 1)
    private val tilt = FloatArray(SpectrumBus.BANDS)

    init {
        val fMin = 40.0
        val fMax = minOf(16000.0, sampleRate / 2.0 * 0.95)
        val fe = DoubleArray(SpectrumBus.BANDS + 1) { fMin * (fMax / fMin).pow(it.toDouble() / SpectrumBus.BANDS) }
        for (i in fe.indices) edges[i] = (fe[i] * n / sampleRate).toInt().coerceIn(1, n / 2 - 1)
        for (b in 0 until SpectrumBus.BANDS) {
            val fc = sqrt(fe[b] * fe[b + 1])
            tilt[b] = (3.0 * ln(fc / 500.0) / ln(2.0)).toFloat()
        }
    }

    fun reset() {
        fill = 0
        buf.fill(0f)
        SpectrumBus.bands = FloatArray(SpectrumBus.BANDS)
    }

    fun push(sample: Float) {
        buf[fill++] = sample
        if (fill == n) {
            analyze()
            System.arraycopy(buf, n / 2, buf, 0, n / 2)
            fill = n / 2
        }
    }

    private fun analyze() {
        for (i in 0 until n) {
            re[i] = buf[i] * window[i]
            im[i] = 0f
        }
        fft()
        val out = FloatArray(SpectrumBus.BANDS)
        val norm = n / 4f
        for (b in 0 until SpectrumBus.BANDS) {
            val start = edges[b]
            val end = maxOf(edges[b + 1], start)
            var m = 0f
            for (k in start..end) {
                val mag = sqrt(re[k] * re[k] + im[k] * im[k])
                if (mag > m) m = mag
            }
            val db = 20f * log10(m / norm + 1e-6f) + tilt[b]
            out[b] = ((db + 72f) / 72f).coerceIn(0f, 1f)
        }
        SpectrumBus.bands = out
    }

    private fun fft() {
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2
            val step = n / len
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = sinT[k * step]
                    val a = i + k
                    val b = a + half
                    val vr = re[b] * wr - im[b] * wi
                    val vi = re[b] * wi + im[b] * wr
                    re[b] = re[a] - vr
                    im[b] = im[a] - vi
                    re[a] = re[a] + vr
                    im[a] = im[a] + vi
                }
                i += len
            }
            len = len shl 1
        }
    }
}
