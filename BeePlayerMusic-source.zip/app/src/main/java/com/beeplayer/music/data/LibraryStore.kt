package com.beeplayer.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Playlist(val id: String, val name: String, val tracks: List<Track>)

/** Daftar putar, favorit, riwayat, dan pustaka impor. Disimpan sebagai JSON di SharedPreferences. */
object LibraryStore {
    private lateinit var prefs: SharedPreferences

    private val _playlists = MutableStateFlow<List<Playlist>>(emptyList())
    val playlists: StateFlow<List<Playlist>> = _playlists.asStateFlow()
    private val _favorites = MutableStateFlow<List<Track>>(emptyList())
    val favorites: StateFlow<List<Track>> = _favorites.asStateFlow()
    private val _recents = MutableStateFlow<List<Track>>(emptyList())
    val recents: StateFlow<List<Track>> = _recents.asStateFlow()
    private val _imported = MutableStateFlow<List<Track>>(emptyList())
    val imported: StateFlow<List<Track>> = _imported.asStateFlow()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("bee_library", Context.MODE_PRIVATE)
        _favorites.value = tracksFromJson(prefs.getString("favorites", null))
        _recents.value = tracksFromJson(prefs.getString("recents", null))
        _imported.value = tracksFromJson(prefs.getString("imported", null))
        _playlists.value = playlistsFromJson(prefs.getString("playlists", null))
    }

    // ---------- JSON ----------

    private fun trackToJson(t: Track): JSONObject = JSONObject().apply {
        put("id", t.id); put("title", t.title); put("artist", t.artist); put("album", t.album)
        put("uri", t.uri); put("artUri", t.artUri ?: JSONObject.NULL)
        put("dur", t.durationMs); put("no", t.trackNo); put("src", t.source.name)
        put("path", t.path ?: JSONObject.NULL)
    }

    private fun trackFromJson(o: JSONObject): Track = Track(
        id = o.getString("id"),
        title = o.optString("title", "Tanpa judul"),
        artist = o.optString("artist", ""),
        album = o.optString("album", ""),
        uri = o.getString("uri"),
        artUri = if (o.isNull("artUri")) null else o.getString("artUri"),
        durationMs = o.optLong("dur", 0),
        trackNo = o.optInt("no", 0),
        source = runCatching { Source.valueOf(o.optString("src", "LOCAL")) }.getOrDefault(Source.LOCAL),
        path = if (o.isNull("path")) null else o.optString("path")
    )

    private fun tracksToArray(l: List<Track>): JSONArray = JSONArray().also { a -> l.forEach { a.put(trackToJson(it)) } }

    private fun tracksFromJson(s: String?): List<Track> = try {
        val a = JSONArray(s ?: "[]")
        (0 until a.length()).map { trackFromJson(a.getJSONObject(it)) }
    } catch (_: Exception) { emptyList() }

    private fun playlistsFromJson(s: String?): List<Playlist> = try {
        val a = JSONArray(s ?: "[]")
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val ta = o.getJSONArray("tracks")
            Playlist(
                o.getString("id"), o.getString("name"),
                (0 until ta.length()).map { trackFromJson(ta.getJSONObject(it)) }
            )
        }
    } catch (_: Exception) { emptyList() }

    private fun savePlaylists() {
        val a = JSONArray()
        _playlists.value.forEach { p ->
            a.put(JSONObject().apply {
                put("id", p.id); put("name", p.name); put("tracks", tracksToArray(p.tracks))
            })
        }
        prefs.edit().putString("playlists", a.toString()).apply()
    }

    private fun saveTracks(key: String, l: List<Track>) {
        prefs.edit().putString(key, tracksToArray(l).toString()).apply()
    }

    // ---------- daftar putar ----------

    fun createPlaylist(name: String): String {
        val id = UUID.randomUUID().toString()
        _playlists.value = _playlists.value + Playlist(id, name.trim().ifEmpty { "Daftar putar" }, emptyList())
        savePlaylists()
        return id
    }

    fun renamePlaylist(id: String, name: String) {
        _playlists.value = _playlists.value.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it }
        savePlaylists()
    }

    fun deletePlaylist(id: String) {
        _playlists.value = _playlists.value.filter { it.id != id }
        savePlaylists()
    }

    /** @return false jika lagu sudah ada di daftar putar. */
    fun addToPlaylist(id: String, track: Track): Boolean {
        var added = false
        _playlists.value = _playlists.value.map { p ->
            if (p.id == id && p.tracks.none { it.id == track.id }) {
                added = true
                p.copy(tracks = p.tracks + track)
            } else p
        }
        if (added) savePlaylists()
        return added
    }

    fun removeFromPlaylist(id: String, trackId: String) {
        _playlists.value = _playlists.value.map { p ->
            if (p.id == id) p.copy(tracks = p.tracks.filter { it.id != trackId }) else p
        }
        savePlaylists()
    }

    // ---------- favorit ----------

    fun toggleFavorite(t: Track) {
        val cur = _favorites.value
        _favorites.value = if (cur.any { it.id == t.id }) cur.filter { it.id != t.id } else listOf(t) + cur
        saveTracks("favorites", _favorites.value)
    }

    // ---------- riwayat ----------

    fun addRecent(t: Track) {
        _recents.value = (listOf(t) + _recents.value.filter { it.id != t.id }).take(50)
        saveTracks("recents", _recents.value)
    }

    fun clearRecents() {
        _recents.value = emptyList()
        saveTracks("recents", emptyList())
    }

    // ---------- impor ----------

    fun addImported(list: List<Track>) {
        val ids = _imported.value.map { it.id }.toSet()
        val fresh = list.filter { it.id !in ids }
        if (fresh.isEmpty()) return
        _imported.value = (_imported.value + fresh).sortedBy { it.title.lowercase() }
        saveTracks("imported", _imported.value)
    }

    fun removeImported(id: String) {
        _imported.value = _imported.value.filter { it.id != id }
        saveTracks("imported", _imported.value)
    }

    fun clearImported() {
        _imported.value = emptyList()
        saveTracks("imported", emptyList())
    }
}
