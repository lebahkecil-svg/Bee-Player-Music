package com.beeplayer.music.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import androidx.media3.exoplayer.ExoPlayer
import com.beeplayer.music.data.AudioSettings
import com.beeplayer.music.data.Presets
import kotlin.math.ln
import kotlin.math.pow

/** Menerapkan preamp, equalizer, bass, virtualizer, dan mode keluaran ke pemutar. */
class AudioEngine(
    private val player: ExoPlayer,
    private val spatial: SpatialAudioProcessor
) {
    private var eq: Equalizer? = null
    private var loud: LoudnessEnhancer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null
    private var last: AudioSettings? = null

    fun attach(sessionId: Int) {
        release()
        if (sessionId == 0) return
        eq = runCatching { Equalizer(0, sessionId).apply { enabled = true } }.getOrNull()
        loud = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()
        bass = runCatching { BassBoost(0, sessionId) }.getOrNull()
        virt = runCatching { Virtualizer(0, sessionId) }.getOrNull()
        last?.let { apply(it) }
    }

    fun release() {
        runCatching { eq?.release() }
        runCatching { loud?.release() }
        runCatching { bass?.release() }
        runCatching { virt?.release() }
        eq = null; loud = null; bass = null; virt = null
    }

    fun apply(s: AudioSettings) {
        last = s
        spatial.mode = s.spatial

        runCatching {
            eq?.let { e ->
                val range = e.bandLevelRange
                for (b in 0 until e.numberOfBands) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000f
                    val mb = (gainAt(hz, s.bands) * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
            }
        }
        // Preamp: positif → LoudnessEnhancer, negatif → volume pemutar
        runCatching {
            if (s.preampDb > 0f) {
                loud?.setTargetGain((s.preampDb * 100).toInt())
                loud?.enabled = true
                player.volume = 1f
            } else {
                loud?.enabled = false
                player.volume = 10.0.pow((s.preampDb / 20f).toDouble()).toFloat().coerceIn(0f, 1f)
            }
        }
        runCatching {
            bass?.let {
                if (it.strengthSupported) {
                    it.setStrength(s.bass.coerceIn(0, 1000).toShort())
                    it.enabled = s.bass > 0
                }
            }
        }
        runCatching {
            virt?.let {
                if (it.strengthSupported) {
                    it.setStrength(s.virtualizer.coerceIn(0, 1000).toShort())
                    it.enabled = s.virtualizer > 0
                }
            }
        }
    }

    /** Interpolasi gain (skala log frekuensi) dari 5 pita acuan ke frekuensi pita perangkat. */
    private fun gainAt(hz: Float, g: List<Float>): Float {
        val f = Presets.bands
        if (g.size < f.size) return 0f
        if (hz <= f.first()) return g.first()
        if (hz >= f.last()) return g.last()
        for (i in 0 until f.size - 1) {
            if (hz <= f[i + 1]) {
                val a = ln(f[i].toFloat())
                val b = ln(f[i + 1].toFloat())
                val t = (ln(hz) - a) / (b - a)
                return g[i] + (g[i + 1] - g[i]) * t
            }
        }
        return g.last()
    }
}
