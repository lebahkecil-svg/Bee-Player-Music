package com.beeplayer.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beeplayer.music.data.SettingsStore
import com.beeplayer.music.service.PlayerController
import com.beeplayer.music.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by SettingsStore.state.collectAsState()
            val skin = Skins.byName(settings.skin)
            BeeTheme(skin) { Root(skin) }
        }
    }
}

private fun audioPermission() =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
private fun Root(skin: Skin) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val vm: LibraryViewModel = viewModel()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, audioPermission()) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        hasPermission = res[audioPermission()] == true
    }
    val requestPermission = {
        val perms = mutableListOf(audioPermission())
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        launcher.launch(perms.toTypedArray())
    }
    LaunchedEffect(Unit) { if (!hasPermission) requestPermission() }

    val ui by PlayerController.ui.collectAsState()
    val items: List<Pair<String, ImageVector>> = listOf(
        "Pustaka" to Icons.Rounded.LibraryMusic,
        "Memutar" to Icons.Rounded.Album,
        "Suara" to Icons.Rounded.GraphicEq,
        "Skin" to Icons.Rounded.Palette
    )

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(skin.bgTop, skin.bgBottom)))) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                Column {
                    if (tab != 1 && ui.current != null) MiniPlayer(onOpen = { tab = 1 })
                    NavigationBar(containerColor = skin.surface.copy(alpha = 0.92f)) {
                        items.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Icon(icon, label) }, label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = skin.bgBottom,
                                    selectedTextColor = skin.accent,
                                    indicatorColor = skin.accent,
                                    unselectedIconColor = skin.text.copy(alpha = 0.7f),
                                    unselectedTextColor = skin.text.copy(alpha = 0.7f)
                                )
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> LibraryScreen(vm, hasPermission, { requestPermission() }, onOpenPlayer = { tab = 1 })
                    1 -> NowPlayingScreen(skin)
                    2 -> SoundScreen()
                    else -> SkinScreen()
                }
            }
        }
    }
}
