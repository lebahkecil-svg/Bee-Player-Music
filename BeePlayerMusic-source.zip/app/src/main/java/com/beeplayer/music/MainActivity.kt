package com.beeplayer.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.beeplayer.music.data.SettingsStore
import com.beeplayer.music.service.PlayerController
import com.beeplayer.music.ui.BeeTheme
import com.beeplayer.music.ui.FavoritesScreen
import com.beeplayer.music.ui.ImportScreen
import com.beeplayer.music.ui.LibraryScreen
import com.beeplayer.music.ui.LibraryViewModel
import com.beeplayer.music.ui.MiniPlayer
import com.beeplayer.music.ui.NowPlayingScreen
import com.beeplayer.music.ui.PlaylistsScreen
import com.beeplayer.music.ui.RecentsScreen
import com.beeplayer.music.ui.SettingsScreen
import com.beeplayer.music.ui.Skin
import com.beeplayer.music.ui.Skins
import kotlinx.coroutines.launch

enum class Screen(val title: String, val icon: ImageVector) {
    LIBRARY("Pustaka", Icons.Rounded.LibraryMusic),
    NOW("Sedang Diputar", Icons.Rounded.Album),
    PLAYLISTS("Daftar Putar", Icons.Rounded.QueueMusic),
    FAVORITES("Favorit", Icons.Rounded.Favorite),
    RECENT("Terakhir Diputar", Icons.Rounded.History),
    IMPORT("Import Pustaka", Icons.Rounded.FileDownload),
    SETTINGS("Pengaturan", Icons.Rounded.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by SettingsStore.state.collectAsState()
            val skin = Skins.byName(settings.skin)
            BeeTheme(skin) { Root(skin) }
        }
    }
}

private fun audioPermission() =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
private fun Root(skin: Skin) {
    val ctx = LocalContext.current
    val vm: LibraryViewModel = viewModel()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var screenName by rememberSaveable { mutableStateOf(Screen.LIBRARY.name) }
    val screen = Screen.valueOf(screenName)
    var openPlaylist by rememberSaveable { mutableStateOf<String?>(null) }
    var showAbout by remember { mutableStateOf(false) }

    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, audioPermission()) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        hasPermission = res[audioPermission()] == true
    }
    val requestPermission = {
        val perms = mutableListOf(audioPermission())
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        launcher.launch(perms.toTypedArray())
    }
    LaunchedEffect(Unit) { if (!hasPermission) requestPermission() }
    LaunchedEffect(hasPermission) { if (hasPermission) vm.loadLocal(ctx) }

    val ui by PlayerController.ui.collectAsState()

    fun go(s: Screen) {
        screenName = s.name
        if (s != Screen.PLAYLISTS) openPlaylist = null
    }

    val inPlaylistDetail = screen == Screen.PLAYLISTS && openPlaylist != null
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }
    BackHandler(enabled = !drawerState.isOpen && inPlaylistDetail) { openPlaylist = null }
    BackHandler(enabled = !drawerState.isOpen && !inPlaylistDetail && screen != Screen.LIBRARY) { go(Screen.LIBRARY) }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(skin.bgTop, skin.bgBottom)))) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = drawerState.isOpen || screen != Screen.NOW,
            drawerContent = {
                ModalDrawerSheet(drawerContainerColor = skin.surface) {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Row(
                            Modifier.padding(horizontal = 20.dp, vertical = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painterResource(R.drawable.bee_logo), null,
                                Modifier.size(52.dp).clip(RoundedCornerShape(12.dp))
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Bee Player Music", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("Pemutar musik", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        HorizontalDivider(Modifier.padding(bottom = 8.dp))
                        Screen.values().forEach { s ->
                            NavigationDrawerItem(
                                label = { Text(s.title) },
                                icon = { Icon(s.icon, null) },
                                selected = screen == s,
                                onClick = {
                                    go(s)
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = skin.accent,
                                    selectedIconColor = skin.bgBottom,
                                    selectedTextColor = skin.bgBottom,
                                    unselectedContainerColor = Color.Transparent,
                                    unselectedIconColor = skin.text,
                                    unselectedTextColor = skin.text
                                )
                            )
                        }
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        NavigationDrawerItem(
                            label = { Text("Tentang") },
                            icon = { Icon(Icons.Rounded.Info, null) },
                            selected = false,
                            onClick = {
                                showAbout = true
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                            colors = NavigationDrawerItemDefaults.colors(
                                unselectedContainerColor = Color.Transparent,
                                unselectedIconColor = skin.text,
                                unselectedTextColor = skin.text
                            )
                        )
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = { Text(screen.title, fontWeight = FontWeight.Bold) },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Rounded.Menu, "Menu")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.Transparent,
                            titleContentColor = skin.text,
                            navigationIconContentColor = skin.text,
                            actionIconContentColor = skin.text
                        )
                    )
                },
                bottomBar = {
                    if (screen != Screen.NOW && ui.current != null) MiniPlayer(onOpen = { go(Screen.NOW) })
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (screen) {
                        Screen.LIBRARY -> LibraryScreen(vm, hasPermission, { requestPermission() }, onOpenPlayer = { go(Screen.NOW) })
                        Screen.NOW -> NowPlayingScreen(skin)
                        Screen.PLAYLISTS -> PlaylistsScreen(openPlaylist, { openPlaylist = it }, onOpenPlayer = { go(Screen.NOW) })
                        Screen.FAVORITES -> FavoritesScreen(onOpenPlayer = { go(Screen.NOW) })
                        Screen.RECENT -> RecentsScreen(onOpenPlayer = { go(Screen.NOW) })
                        Screen.IMPORT -> ImportScreen(vm, hasPermission, { requestPermission() }, onOpenPlayer = { go(Screen.NOW) })
                        Screen.SETTINGS -> SettingsScreen(skin)
                    }
                }
            }
        }
    }

    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            title = { Text("Bee Player Music") },
            text = {
                Text(
                    "Versi 1.0\n\nPreamp & equalizer, keluaran Mono/Stereo/Real 3D/4D, putar mundur, " +
                            "daftar putar, favorit, impor pustaka, lirik, dan spektrum bergerak mengikuti musik."
                )
            },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("Tutup") } }
        )
    }
}
