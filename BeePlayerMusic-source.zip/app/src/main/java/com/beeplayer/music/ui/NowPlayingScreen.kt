package com.beeplayer.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import com.beeplayer.music.data.LibraryStore
import com.beeplayer.music.data.Lyrics
import com.beeplayer.music.data.LyricsRepo
import com.beeplayer.music.data.SettingsStore
import com.beeplayer.music.data.SpatialMode
import com.beeplayer.music.data.SpectrumStyle
import com.beeplayer.music.data.Track
import com.beeplayer.music.data.formatTime
import com.beeplayer.music.service.PlayerController

@Composable
fun NowPlayingScreen(skin: Skin) {
    val ui by PlayerController.ui.collectAsState()
    val pos by PlayerController.positionMs.collectAsState()
    val settings by SettingsStore.state.collectAsState()
    val favs by LibraryStore.favorites.collectAsState()
    val track = ui.current
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }

    if (track == null) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                VinylDisk(false, skin.accent, Modifier.size(220.dp))
                Spacer(Modifier.height(16.dp))
                Text("Belum ada lagu diputar.\nPilih lagu dari Pustaka.", textAlign = TextAlign.Center)
            }
        }
        return
    }
    val isFav = favs.any { it.id == track.id }
    val bigSpectrum = settings.hero == "spectrum"
    val squareStyle = settings.spectrum == SpectrumStyle.CIRCLE || settings.spectrum == SpectrumStyle.PULSE

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ---- panggung: sampul / piringan hitam / spektrum besar / lirik ----
        Box(Modifier.fillMaxWidth().height(270.dp), contentAlignment = Alignment.Center) {
            when {
                showLyrics -> LyricsView(track, pos, skin)
                bigSpectrum -> SpectrumView(
                    settings.spectrum, skin.accent, skin.accent2, ui.isPlaying, settings.spectrumGain,
                    Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.45f)).padding(12.dp)
                )
                else -> {
                    var coverLoaded by remember(track.id) { mutableStateOf(false) }
                    val shrink = if (ui.isPlaying) 1f else 0.94f
                    Box(Modifier.size(250.dp).scale(shrink), contentAlignment = Alignment.Center) {
                        if (!coverLoaded) VinylDisk(ui.isPlaying, skin.accent, Modifier.fillMaxSize())
                        if (track.artUri != null) {
                            AsyncImage(
                                model = track.artUri, contentDescription = "Sampul",
                                modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp))
                                    .alpha(if (coverLoaded) 1f else 0f),
                                contentScale = ContentScale.Crop,
                                onSuccess = { coverLoaded = true },
                                onError = { coverLoaded = false }
                            )
                        }
                    }
                }
            }
        }

        // ---- spektrum kecil di bawah sampul ----
        if (!bigSpectrum) {
            Spacer(Modifier.height(6.dp))
            SpectrumView(
                settings.spectrum, skin.accent, skin.accent2, ui.isPlaying, settings.spectrumGain,
                Modifier.fillMaxWidth().height(if (squareStyle) 120.dp else 60.dp)
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            buildString {
                if (track.trackNo > 0) append("Trek ${track.trackNo}")
                if (ui.queue.size > 1) { if (isNotEmpty()) append("  •  "); append("${ui.index + 1} dari ${ui.queue.size} di antrean") }
            },
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary
        )
        Text(
            track.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
        Text(
            listOf(track.artist, track.album).filter { it.isNotBlank() }.joinToString(" • "),
            maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            IconButton(onClick = { LibraryStore.toggleFavorite(track) }) {
                Icon(
                    if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorit",
                    tint = if (isFav) skin.accent else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { addDialog = true }) {
                Icon(Icons.Rounded.PlaylistAdd, "Tambah ke daftar putar", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        DotProgress(
            positionMs = pos, durationMs = ui.durationMs, playing = ui.isPlaying,
            accent = skin.accent, dim = skin.text.copy(alpha = 0.25f),
            onSeek = { PlayerController.seekTo(it) }
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(formatTime(pos), Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
            Text("Durasi ${formatTime(ui.durationMs)}", Modifier.weight(1.4f), textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("-${formatTime((ui.durationMs - pos).coerceAtLeast(0))}", Modifier.weight(1f), textAlign = TextAlign.End,
                style = MaterialTheme.typography.labelLarge)
        }

        // ---- kontrol ----
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { PlayerController.toggleShuffle() }) {
                Icon(Icons.Rounded.Shuffle, "Acak",
                    tint = if (ui.shuffle) skin.accent else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { PlayerController.previous() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Sebelumnya", Modifier.size(36.dp))
            }
            FilledIconButton(
                onClick = { PlayerController.togglePlay() }, modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = skin.accent, contentColor = MaterialTheme.colorScheme.onPrimary)
            ) {
                if (ui.buffering || ui.reverseLoading) CircularProgressIndicator(Modifier.size(30.dp), strokeWidth = 3.dp, color = MaterialTheme.colorScheme.onPrimary)
                else Icon(if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Putar/Jeda", Modifier.size(40.dp))
            }
            IconButton(onClick = { PlayerController.next() }, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipNext, "Berikutnya", Modifier.size(36.dp))
            }
            IconButton(onClick = { PlayerController.cycleRepeat() }) {
                Icon(
                    if (ui.repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Ulangi",
                    tint = if (ui.repeat != Player.REPEAT_MODE_OFF) skin.accent else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // ---- fitur tambahan ----
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
            FilterChip(
                selected = ui.reverse, onClick = { PlayerController.setReverse(!ui.reverse) },
                label = { Text(if (ui.reverseLoading) "Menyiapkan…" else "Mundur") },
                leadingIcon = { Icon(Icons.Rounded.FastRewind, null, Modifier.size(18.dp)) }
            )
            FilterChip(
                selected = showLyrics, onClick = { showLyrics = !showLyrics },
                label = { Text("Lirik") },
                leadingIcon = { Icon(Icons.Rounded.Subject, null, Modifier.size(18.dp)) }
            )
            FilterChip(
                selected = bigSpectrum,
                onClick = { SettingsStore.update { it.copy(hero = if (bigSpectrum) "cover" else "spectrum") } },
                label = { Text("Spektrum") },
                leadingIcon = { Icon(Icons.Rounded.GraphicEq, null, Modifier.size(18.dp)) }
            )
        }
        Spacer(Modifier.height(2.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)) {
            SpatialMode.values().forEach { m ->
                FilterChip(
                    selected = settings.spatial == m,
                    onClick = { SettingsStore.update { it.copy(spatial = m) } },
                    label = { Text(m.label.replace("Real ", ""), fontSize = 13.sp) }
                )
            }
        }
        ui.message?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(12.dp))
    }
    if (addDialog) AddToPlaylistDialog(track) { addDialog = false }
}

@Composable
private fun LyricsView(track: Track, pos: Long, skin: Skin) {
    var lyrics by remember(track.id) { mutableStateOf<Lyrics?>(null) }
    var loading by remember(track.id) { mutableStateOf(true) }
    LaunchedEffect(track.id) {
        loading = true
        lyrics = LyricsRepo.fetch(track)
        loading = false
    }
    Box(
        Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
        contentAlignment = Alignment.Center
    ) {
        val l = lyrics
        when {
            loading -> CircularProgressIndicator()
            l == null -> Text("Lirik tidak ditemukan untuk lagu ini.", textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
            else -> {
                val state = rememberLazyListState()
                val cur = if (l.synced) l.lines.indexOfLast { it.timeMs <= pos } else -1
                LaunchedEffect(cur) { if (cur >= 0) state.animateScrollToItem((cur - 2).coerceAtLeast(0)) }
                LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp)) {
                    itemsIndexed(l.lines) { i, line ->
                        val active = i == cur
                        Text(
                            line.text.ifEmpty { "♪" },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            textAlign = TextAlign.Center,
                            fontSize = if (active) 20.sp else 16.sp,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                            color = if (active) skin.accent else MaterialTheme.colorScheme.onSurface.copy(alpha = if (l.synced) 0.55f else 0.9f)
                        )
                    }
                }
            }
        }
    }
}
